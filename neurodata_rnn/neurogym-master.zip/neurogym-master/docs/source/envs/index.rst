Environments
===================================

.. toctree::
    :maxdepth: 1

    AntiReach-v0
    Bandit-v0
    ContextDecisionMaking-v0
    DawTwoStep-v0
    DelayComparison-v0
    DelayMatchCategory-v0
    DelayMatchSample-v0
    DelayMatchSampleDistractor1D-v0
    DelayPairedAssociation-v0
    DualDelayMatchSample-v0
    EconomicDecisionMaking-v0
    GoNogo-v0
    HierarchicalReasoning-v0
    IntervalDiscrimination-v0
    MotorTiming-v0
    MultiSensoryIntegration-v0
    OneTwoThreeGo-v0
    PerceptualDecisionMaking-v0
    PerceptualDecisionMakingDelayResponse-v0
    PostDecisionWager-v0
    ProbabilisticReasoning-v0
    PulseDecisionMaking-v0
    Reaching1D-v0
    Reaching1DWithSelfDistraction-v0
    ReachingDelayResponse-v0
    ReadySetGo-v0
    SingleContextDecisionMaking-v0
    psychopy.RandomDotMotion-v0
    psychopy.SpatialSuppressMotion-v0
    psychopy.VisualSearch-v0
