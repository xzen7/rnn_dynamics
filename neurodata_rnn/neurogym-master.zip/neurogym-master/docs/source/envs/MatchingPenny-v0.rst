MatchingPenny-v0
--------------------------------------------------
.. autoclass:: neurogym.envs.matchingpenny.MatchingPenny
    :members:
    :exclude-members: new_trial

    Reference paper
        `Prefrontal cortex and decision making in a          mixed-strategy game <https://www.nature.com/articles/nn1209>`__

    Tags
        :ref:`tag-two-alternative`

    Sample run
        .. image:: ../_static/MatchingPenny-v0_examplerun.png
            :width: 600

