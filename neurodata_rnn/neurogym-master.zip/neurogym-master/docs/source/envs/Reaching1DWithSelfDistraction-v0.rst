Reaching1DWithSelfDistraction-v0
--------------------------------------------------
.. autoclass:: neurogym.envs.reaching.Reaching1DWithSelfDistraction
    :members:
    :exclude-members: new_trial

    Tags
        :ref:`tag-motor`,         :ref:`tag-steps action space`

    Reinforcement learning and analysis of this task
        `[Open in colab] <https://colab.research.google.com/github/neurogym/ngym_usage/blob/master/training/auto_notebooks/rl/Reaching1DWithSelfDistraction-v0.ipynb>`_
        `[Jupyter notebook Source] <https://github.com/neurogym/ngym_usage/blob/master/training/auto_notebooks/rl/Reaching1DWithSelfDistraction-v0.ipynb>`_
    Sample run
        .. image:: ../_static/Reaching1DWithSelfDistraction-v0_examplerun.png
            :width: 600

