************
Installation
************

You can perform a minimal install of ``neurogym`` with:

.. code:: console

    git clone https://github.com/gyyang/neurogym.git
    cd neurogym
    pip install -e .
