from neurogym.tests.test_envs import test_run
from neurogym.tests.test_speed import test_speed
